declare module "https://deno.land/x/denoflate@1.2.1/mod.ts" {
  export function gunzip(input: Uint8Array): Uint8Array;
}

package main

const esbuildVersion = "0.14.25"

# esbuild

This is the NetBSD AMD64 binary for esbuild, a JavaScript bundler and minifier. See https://github.com/evanw/esbuild for details.

⚠️ Note: NetBSD is not one of [Node's supported platforms](https://nodejs.org/api/process.html#process_process_platform), so installing esbuild may or may not work on NetBSD depending on how Node has been patched. This is not a problem with esbuild. ⚠️

[![GoDoc](https://godoc.org/github.com/gohugoio/localescompressed?status.svg)](https://godoc.org/github.com/gohugoio/localescompressed)
[![Go](https://github.com/gohugoio/localescompressed/actions/workflows/go.yml/badge.svg)](https://github.com/gohugoio/localescompressed/actions/workflows/go.yml)


The locales from https://github.com/gohugoio/locales in one package/struct.
